package com.aug.ecommerce.api.application;

import com.aug.ecommerce.api.domain.model.orden.Orden;
import com.aug.ecommerce.api.domain.model.pago.Pago;
import com.aug.ecommerce.api.domain.event.OrdenPagada;
import com.aug.ecommerce.api.domain.service.ProcesadorDePago;

public class ServicioAplicacionPago {

    private final ProcesadorDePago procesadorDePago;

    public ServicioAplicacionPago(ProcesadorDePago procesadorDePago) {
        this.procesadorDePago = procesadorDePago;
    }

    public OrdenPagada confirmarPago(Pago pago, Orden orden) {
        procesadorDePago.procesar(pago, orden);
        return new OrdenPagada(orden.getId());
    }
}

