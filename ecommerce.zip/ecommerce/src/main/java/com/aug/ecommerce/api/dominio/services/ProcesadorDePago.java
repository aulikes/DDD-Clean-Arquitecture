package com.aug.ecommerce.api.dominio.services;

import com.aug.ecommerce.api.dominio.entidades.orden.Orden;
import com.aug.ecommerce.api.dominio.entidades.pago.Pago;

public class ProcesadorDePago {

    public void procesarPago(Pago pago, Orden orden) {
        // Validaciones cruzadas entre aggregates
        if (!pago.getOrdenId().equals(orden.getId())) {
            throw new IllegalArgumentException("El pago no pertenece a la orden");
        }

        if (pago.getEstado() != Pago.Estado.CONFIRMADO) {
            throw new IllegalStateException("No se puede aplicar un pago que no está confirmado");
        }

        double totalOrden = orden.calcularTotal();
        if (Double.compare(pago.getMonto(), totalOrden) != 0) {
            throw new IllegalStateException("El monto del pago no coincide con el total de la orden");
        }

        // Aplicar el cambio de estado en la orden
        orden.pagar();
    }
}

