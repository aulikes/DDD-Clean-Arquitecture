package com.aug.ecommerce.domain.repository;

import com.aug.ecommerce.domain.model.cliente.Cliente;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

public interface ClienteRepository {
    void save(Cliente cliente);
    Optional<Cliente> findById(UUID id);
    List<Cliente> findAll();
    void deleteById(UUID id);

    Optional<Cliente> findByEmail(String email);
}
