package com.aug.ecommerce.api.domain.service;

import com.aug.ecommerce.api.domain.model.orden.Orden;
import com.aug.ecommerce.api.domain.model.envio.Envio;
import com.aug.ecommerce.api.domain.event.OrdenEntregada;

public class ProcesadorDeEntrega {

    public OrdenEntregada procesar(Orden orden, Envio envio) {
        envio.entregar();
        orden.entregar();
        return new OrdenEntregada(orden.getId());
    }
}
