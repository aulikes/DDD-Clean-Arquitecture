package com.aug.ecommerce.api.domain.service;

import com.aug.ecommerce.api.domain.model.orden.Orden;
import com.aug.ecommerce.api.domain.event.OrdenCancelada;

public class ProcesadorDeCancelacion {

    public OrdenCancelada procesar(Orden orden) {
        orden.cancelar();
        return new OrdenCancelada(orden.getId());
    }
}
