package com.aug.ecommerce.api.application;

import com.aug.ecommerce.api.domain.model.orden.Orden;
import com.aug.ecommerce.api.domain.model.envio.Envio;
import com.aug.ecommerce.api.domain.event.OrdenEnviada;
import com.aug.ecommerce.api.domain.event.OrdenEntregada;
import com.aug.ecommerce.api.domain.service.ProcesadorDeEnvio;
import com.aug.ecommerce.api.domain.service.ProcesadorDeEntrega;

public class ServicioAplicacionEnvio {

    private final ProcesadorDeEnvio procesadorDeEnvio;
    private final ProcesadorDeEntrega procesadorDeEntrega;

    public ServicioAplicacionEnvio(
            ProcesadorDeEnvio procesadorDeEnvio,
            ProcesadorDeEntrega procesadorDeEntrega
    ) {
        this.procesadorDeEnvio = procesadorDeEnvio;
        this.procesadorDeEntrega = procesadorDeEntrega;
    }

    public OrdenEnviada despachar(Orden orden, Envio envio, String tracking) {
        return procesadorDeEnvio.procesar(orden, envio, tracking);
    }

    public OrdenEntregada entregar(Orden orden, Envio envio) {
        return procesadorDeEntrega.procesar(orden, envio);
    }
}
