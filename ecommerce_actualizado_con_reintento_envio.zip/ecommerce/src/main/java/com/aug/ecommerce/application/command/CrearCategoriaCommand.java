package com.aug.ecommerce.application.command;

public record CrearCategoriaCommand(String nombre, String descripcion) { }
