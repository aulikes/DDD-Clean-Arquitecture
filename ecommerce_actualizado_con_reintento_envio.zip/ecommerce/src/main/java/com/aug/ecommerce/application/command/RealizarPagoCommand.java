package com.aug.ecommerce.application.command;

public record RealizarPagoCommand(Long idOrden, String medioPago) {
}
