package com.aug.ecommerce.domain.model.pago;

public enum EstadoPago {
    PENDIENTE, CONFIRMADO, FALLIDO
}
