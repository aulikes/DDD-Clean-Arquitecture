package com.aug.ecommerce.infrastructure.listener.eventlistener;

public enum ValidacionCrearOrden {
    CLIENTE, PRODUCTO, STOCK
}
